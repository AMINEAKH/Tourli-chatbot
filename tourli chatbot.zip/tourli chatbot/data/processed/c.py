import json

DATASET_PATH = "C:\\Users\\akhda\\Desktop\\uni\\python projects\\final progect\\data\\processed\\edge_cases_cleaned.json"
 # <-- change to your actual file
NEW_QUESTIONS = [
    "How much does it cost to travel in Morocco?",
    "What's the local cuisine like in Morocco?",
    "What language is spoken in Morocco?",
    "Is Morocco a safe country for tourists?",
    "What currency is used in Morocco?",
    "What are the main religions in Morocco?",
    "Do I need a visa to visit Morocco?",
    "What’s the culture like in Morocco?",
    "What power plug type is used in Morocco?",
    "Is tap water safe to drink in Morocco?",
    "What’s the tipping culture like in Morocco?",
    "How do people usually get around in Morocco?"
]

def load_dataset():
    with open(DATASET_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def check_duplicates(dataset, questions):
    existing = set(item["question"].strip().lower() for item in dataset)
    duplicates = []
    
    for q in questions:
        if q.strip().lower() in existing:
            duplicates.append(q)
    
    return duplicates

if __name__ == "__main__":
    dataset = load_dataset()
    duplicates = check_duplicates(dataset, NEW_QUESTIONS)

    if duplicates:
        print("\n⚠️ Duplicate questions found:")
        for q in duplicates:
            print(" -", q)
    else:
        print("\n🎉 No duplicates! All questions are new.")
