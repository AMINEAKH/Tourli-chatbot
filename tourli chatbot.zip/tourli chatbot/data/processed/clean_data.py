import json
import re

INPUT = "data/raw/dataset1.json"
OUTPUT = "data/processed/cleaned_dataset.json"

def clean_text(text):
    if not isinstance(text, str):
        return ""
    text = text.strip()
    text = re.sub(r"\s+", " ", text)  # normalize spaces
    return text

def clean_entry(entry):
    return {
        "id": entry.get("id"),
        "city": clean_text(entry.get("city", "")).title(),
        "category": clean_text(entry.get("category", "").lower()),
        "intent": clean_text(entry.get("intent", "").lower()),
        "question": clean_text(entry.get("question", "")),
        "assistant": clean_text(entry.get("assistant", ""))
    }

def main():
    with open(INPUT, "r", encoding="utf-8") as f:
        data = json.load(f)

    cleaned = []
    seen_questions = set()

    for entry in data:
        c = clean_entry(entry)

        # skip empty or bad entries
        if not c["question"] or not c["assistant"]:
            continue

        # skip duplicates
        q_lower = c["question"].lower()
        if q_lower in seen_questions:
            continue

        seen_questions.add(q_lower)
        cleaned.append(c)

    print(f"✔ Cleaned entries: {len(cleaned)}")

    with open(OUTPUT, "w", encoding="utf-8") as f:
        json.dump(cleaned, f, indent=4, ensure_ascii=False)

    print("🔥 Saved:", OUTPUT)

if __name__ == "__main__":
    main()
